/// Public API of the player_shared package.
/// All three apps import this single file.
library player_shared;

// Storage
export 'src/storage/storage_service.dart';

// Models
export 'src/parser/m3u_parser.dart';
export 'src/player/media_file.dart';

// Controllers / settings
export 'src/controller/settings_controller.dart';
export 'src/controller/playback_bar_controller.dart';

// Player core mixins & backend abstraction
export 'src/player/player_core.dart';
export 'src/player/player_backend.dart';
export 'src/player/mpv_backend.dart';

// Music metadata & models
export 'src/music/audio_metadata.dart';
export 'src/music/id3_writer.dart';
export 'src/music/rich_music_file.dart';
export 'src/music/song_entry.dart';
export 'src/music/artist_splitter.dart';

// Online metadata matching (QQ Music / NetEase Music / iTunes search +
// fuzzy match + fill-missing-fields + write back to ID3 tags). Source query
// order is chosen dynamically per-song based on detected artist language
// (see ArtistLanguageDetector + SongMatcher). UI-agnostic; each platform
// wires up its own trigger (manual button / auto-on-scan) against this.
export 'src/online_match/online_song_info.dart';
export 'src/online_match/artist_language_detector.dart';
export 'src/online_match/qq_music_source.dart';
export 'src/online_match/netease_music_source.dart';
export 'src/online_match/itunes_music_source.dart';
export 'src/online_match/song_matcher.dart';
export 'src/online_match/online_metadata_service.dart';

// Local media scanning (phone & TV shared)
export 'src/scanner/local_scanner.dart';

// Permission handling (phone & TV shared)
export 'src/permission/permission_util.dart';

// Media cache: video thumbnails on disk (phone & TV shared)
export 'src/media_cache/app_data_dir.dart';
export 'src/media_cache/video_thumbnail_generator.dart';

// Music cover art: in-memory, incremental-batch loading (all three apps
// share this strategy now — audio covers are never written to disk).
export 'src/media_cache/audio_cover_memory_cache.dart';

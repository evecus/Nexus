/// 纯 Dart ID3v2.3 标签写入器，与 [AudioMetadataReader] 配套使用。
///
/// 采用"整体重写"策略：不尝试在原有 tag 结构里做最小范围的增量修改，
/// 而是重新构造一个全新的 ID3v2.3 tag（只包含本次要写入的帧），再拼接
/// 到原音频数据（跳过文件原有的 ID3v2 tag 区，若存在的话）前面，整体
/// 写回文件。实现简单、行为可预测，代价是即使只改一个字段也会重写
/// 整个 tag 头——对 tag 头本身（通常几 KB～几十 KB，包含一张封面时）
/// 而言这个开销可以忽略，不会重写音频数据本身。
///
/// 只处理 MP3(ID3v2)。FLAC/OGG 使用 Vorbis Comment 规范，结构与 ID3
/// 完全不同，写入逻辑不在这个文件的范围内。
library id3_writer;

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

class Id3Writer {
  Id3Writer._();

  /// 写入/更新 MP3 文件的 TIT2(标题) / TPE1(艺术家) / TALB(专辑) 帧。
  ///
  /// 只会覆盖传入的非 null 字段；传 null 表示"不改动这个字段"——如果
  /// 原文件已有对应帧，会原样保留（连同其原始字节，不重新编码），避免
  /// 不必要的信息损失（比如原本是 UTF-16 编码的文本，不会被强制转成
  /// UTF-8 再写回）。
  ///
  /// [coverBytes] / [coverMime]：可选，传入时会写入/替换 APIC 帧；
  /// 不传则保留原有封面（若有）。
  /// [lyrics]：可选，LRC 文本，传入时会写入/替换 USLT 帧；不传则保留
  /// 原有歌词（若有）。
  ///
  /// 返回 true 表示写入成功；文件不存在、不是合法 MP3、或写入过程中
  /// 出现 IO 异常都返回 false，不会抛出异常（调用方按"写入失败，稍后
  /// 可以重试"处理即可，不需要在写标签这种非核心路径上处理异常类型）。
  static Future<bool> writeTags(
    String filePath, {
    String? title,
    String? artist,
    String? album,
    Uint8List? coverBytes,
    String? coverMime,
    String? lyrics,
  }) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;

      final original = await file.readAsBytes();
      final existingTag = _readExistingTag(original);

      // 音频数据起点：跳过原有 ID3v2 tag（如果有的话），没有的话就是
      // 整个文件都是音频数据。
      final audioStart = existingTag?.totalSize ?? 0;
      if (audioStart > original.length) return false; // 数据不自洽，放弃
      final audioBytes = original.sublist(audioStart);

      // 组装最终写入的各帧内容：显式传入的字段优先，否则沿用原 tag 里
      // 已解析出的原始帧字节（原样保留，不重新编码）。
      final frames = <_Id3Frame>[];

      _addTextFrame(frames, 'TIT2', title, existingTag?.rawTextFrames['TIT2']);
      _addTextFrame(frames, 'TPE1', artist, existingTag?.rawTextFrames['TPE1']);
      _addTextFrame(frames, 'TALB', album, existingTag?.rawTextFrames['TALB']);

      if (coverBytes != null && coverBytes.isNotEmpty) {
        frames.add(_buildApicFrame(coverBytes, coverMime ?? 'image/jpeg'));
      } else if (existingTag?.rawApicFrame != null) {
        frames.add(_Id3Frame('APIC', existingTag!.rawApicFrame!));
      }

      if (lyrics != null && lyrics.isNotEmpty) {
        frames.add(_buildUsltFrame(lyrics));
      } else if (existingTag?.rawUsltFrame != null) {
        frames.add(_Id3Frame('USLT', existingTag!.rawUsltFrame!));
      }

      // 保留原 tag 里其它我们不关心、但也不想丢弃的帧(如 TRCK/TYER/
      // TCON 等)，原样透传，只是本次不会更新它们的内容。
      if (existingTag != null) {
        for (final entry in existingTag.otherFrames) {
          frames.add(entry);
        }
      }

      final tagBytes = _buildTag(frames);
      final output = BytesBuilder(copy: false)
        ..add(tagBytes)
        ..add(audioBytes);

      await file.writeAsBytes(output.toBytes(), flush: true);
      return true;
    } catch (_) {
      return false;
    }
  }

  static void _addTextFrame(
    List<_Id3Frame> frames,
    String frameId,
    String? newValue,
    Uint8List? rawExisting,
  ) {
    if (newValue != null && newValue.trim().isNotEmpty) {
      frames.add(_buildTextFrame(frameId, newValue.trim()));
    } else if (rawExisting != null) {
      frames.add(_Id3Frame(frameId, rawExisting));
    }
  }

  // ── 读取原有 tag(供写入时保留未修改的帧) ──────────────────────────────

  static _ExistingTag? _readExistingTag(Uint8List data) {
    if (data.length < 10) return null;
    if (data[0] != 0x49 || data[1] != 0x44 || data[2] != 0x33) return null; // "ID3"

    final version = data[3];
    final flags = data[5];
    final tagSize = _syncsafeInt(data, 6) + 10;
    final limit = tagSize < data.length ? tagSize : data.length;

    int pos = 10;
    if ((flags & 0x40) != 0) {
      if (pos + 4 > limit) return _ExistingTag.empty(tagSize);
      final extSize =
          version == 4 ? _syncsafeInt(data, pos) : _readInt(data, pos);
      pos += extSize;
    }

    final rawTextFrames = <String, Uint8List>{};
    Uint8List? rawApicFrame;
    Uint8List? rawUsltFrame;
    final otherFrames = <_Id3Frame>[];

    const knownTextFrames = {'TIT2', 'TPE1', 'TALB'};

    while (pos + 10 <= limit) {
      final b0 = data[pos];
      if (b0 < 0x41 || b0 > 0x5A) break; // 到达 padding 区，结束扫描

      final frameId = String.fromCharCodes(data.sublist(pos, pos + 4));
      final frameSize =
          version == 4 ? _syncsafeInt(data, pos + 4) : _readInt(data, pos + 4);
      pos += 10;

      if (frameSize <= 0 || pos + frameSize > data.length) break;
      final payload = data.sublist(pos, pos + frameSize);
      pos += frameSize;

      if (knownTextFrames.contains(frameId)) {
        rawTextFrames[frameId] = payload;
      } else if (frameId == 'APIC') {
        rawApicFrame = payload;
      } else if (frameId == 'USLT') {
        rawUsltFrame = payload;
      } else {
        // 其它不关心的帧原样保留，写回时不丢失(如流派、音轨号等)。
        otherFrames.add(_Id3Frame(frameId, payload));
      }
    }

    return _ExistingTag(
      totalSize: tagSize,
      rawTextFrames: rawTextFrames,
      rawApicFrame: rawApicFrame,
      rawUsltFrame: rawUsltFrame,
      otherFrames: otherFrames,
    );
  }

  // ── 帧构造 ─────────────────────────────────────────────────────────────

  /// 文本帧统一用 UTF-8 编码(encoding byte = 3)写入，避免处理 UTF-16
  /// BOM 的复杂度；主流播放器/标签编辑器均已良好支持 ID3v2.3 下的
  /// UTF-8 编码文本帧。
  static _Id3Frame _buildTextFrame(String frameId, String text) {
    final builder = BytesBuilder(copy: false)
      ..addByte(3) // UTF-8
      ..add(utf8.encode(text));
    return _Id3Frame(frameId, builder.toBytes());
  }

  static _Id3Frame _buildApicFrame(Uint8List coverBytes, String mime) {
    final builder = BytesBuilder(copy: false)
      ..addByte(0) // encoding: ISO-8859-1(描述字段留空，编码不影响图片本身)
      ..add(ascii.encode(mime))
      ..addByte(0) // MIME 结尾 null
      ..addByte(3) // picture type: 3 = Cover (front)
      ..addByte(0) // description 结尾 null(空描述)
      ..add(coverBytes);
    return _Id3Frame('APIC', builder.toBytes());
  }

  static _Id3Frame _buildUsltFrame(String lrcText) {
    final builder = BytesBuilder(copy: false)
      ..addByte(3) // UTF-8
      ..add(ascii.encode('und')) // language: undetermined
      ..addByte(0) // description 结尾 null(空描述)
      ..add(utf8.encode(lrcText));
    return _Id3Frame('USLT', builder.toBytes());
  }

  /// 把帧列表打包成完整的 ID3v2.3 tag(含 10 字节 header)。
  static Uint8List _buildTag(List<_Id3Frame> frames) {
    final framesBuilder = BytesBuilder(copy: false);
    for (final frame in frames) {
      final idBytes = ascii.encode(frame.id.padRight(4).substring(0, 4));
      framesBuilder.add(idBytes);
      framesBuilder.add(_writeInt(frame.payload.length)); // ID3v2.3: 非 syncsafe
      framesBuilder.addByte(0); // flags high byte
      framesBuilder.addByte(0); // flags low byte
      framesBuilder.add(frame.payload);
    }
    final frameBytes = framesBuilder.toBytes();

    final header = BytesBuilder(copy: false)
      ..add(ascii.encode('ID3'))
      ..addByte(3) // version major: ID3v2.3
      ..addByte(0) // version minor
      ..addByte(0) // flags
      ..add(_writeSyncsafeInt(frameBytes.length));

    return (BytesBuilder(copy: false)
          ..add(header.toBytes())
          ..add(frameBytes))
        .toBytes();
  }

  // ── 整数编解码 ─────────────────────────────────────────────────────────

  static int _syncsafeInt(Uint8List d, int off) =>
      ((d[off] & 0x7f) << 21) |
      ((d[off + 1] & 0x7f) << 14) |
      ((d[off + 2] & 0x7f) << 7) |
      (d[off + 3] & 0x7f);

  static int _readInt(Uint8List d, int off) =>
      ((d[off] & 0xff) << 24) |
      ((d[off + 1] & 0xff) << 16) |
      ((d[off + 2] & 0xff) << 8) |
      (d[off + 3] & 0xff);

  static Uint8List _writeInt(int value) {
    return Uint8List.fromList([
      (value >> 24) & 0xff,
      (value >> 16) & 0xff,
      (value >> 8) & 0xff,
      value & 0xff,
    ]);
  }

  /// ID3v2 tag size 字段要求 syncsafe 编码：每字节只用低 7 位，
  /// 最高位恒为 0，避免与帧同步标记(0xFF)混淆。
  static Uint8List _writeSyncsafeInt(int value) {
    return Uint8List.fromList([
      (value >> 21) & 0x7f,
      (value >> 14) & 0x7f,
      (value >> 7) & 0x7f,
      value & 0x7f,
    ]);
  }
}

class _Id3Frame {
  final String id;
  final Uint8List payload;
  const _Id3Frame(this.id, this.payload);
}

class _ExistingTag {
  /// 原 tag 在文件中的总字节数(header 10 字节 + tag 体，用于定位音频
  /// 数据的起始偏移)。
  final int totalSize;
  final Map<String, Uint8List> rawTextFrames;
  final Uint8List? rawApicFrame;
  final Uint8List? rawUsltFrame;
  final List<_Id3Frame> otherFrames;

  const _ExistingTag({
    required this.totalSize,
    required this.rawTextFrames,
    required this.rawApicFrame,
    required this.rawUsltFrame,
    required this.otherFrames,
  });

  factory _ExistingTag.empty(int totalSize) => _ExistingTag(
        totalSize: totalSize,
        rawTextFrames: const {},
        rawApicFrame: null,
        rawUsltFrame: null,
        otherFrames: const [],
      );
}

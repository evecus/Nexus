/// 歌手语言判断 —— 用于决定在线匹配的数据源查询顺序。
///
/// 判断依据是**歌手名**而不是歌名:歌名经常中英文混用(很多华语歌曲
/// 直接用英文做标题,反之亦然),不是可靠的语言信号;歌手名相对稳定
/// 地反映"这个人/组合属于哪个曲库生态"——一个中文名字的歌手,他的
/// 作品大概率能在 QQ 音乐/网易云音乐搜到,而不是 iTunes。
///
/// 具体规则:歌手名中只要包含任意一个中文字符(CJK 统一表意文字区段),
/// 就判定为"中文歌手";歌手名为空,或者不含中文字符(纯英文/日文假名/
/// 韩文谚文等),判定为"外文歌手"。
///
/// 这是一个粗粒度的启发式规则,不追求覆盖所有语言(比如不特别区分
/// 日语、韩语、法语),原因是本次接入的三个数据源里:QQ 音乐、网易云
/// 音乐覆盖"中文歌手 + 华语乐坛引进的外语歌曲",iTunes 覆盖"全球
/// 曲库,尤其欧美/日韩"——本质上只需要"是否优先查华语平台"这一个
/// 二元判断,不需要更细的语言分类。
library artist_language_detector;

class ArtistLanguageDetector {
  ArtistLanguageDetector._();

  /// CJK 统一表意文字(基本区 + 扩展 A 区),覆盖绝大多数简体/繁体中文
  /// 汉字。不包含日文假名(ぁ-ん / ァ-ヶ)、韩文谚文(가-힣)专属区段,
  /// 因此"周杰伦"会被判定为中文,而纯假名的日文歌手名、纯谚文的韩文
  /// 歌手名不会被误判为中文。
  static final RegExp _cjkPattern = RegExp(
    r'[\u4e00-\u9fff\u3400-\u4dbf]',
  );

  /// 判断歌手名是否应被当作"中文歌手"处理。
  ///
  /// 多歌手场景(如 "周杰伦、Ade")只要其中包含中文字符即可判定为中文,
  /// 因为该作品大概率仍然收录在华语曲库里。
  static bool isChineseArtist(String? artist) {
    if (artist == null || artist.trim().isEmpty) return false;
    return _cjkPattern.hasMatch(artist);
  }

  /// 综合判断"这首歌应该优先当中文歌处理,还是外文歌处理"。
  ///
  /// 优先看歌手名(更可靠的语言信号);歌手名为空时(常见于本地标签
  /// 缺失、正是需要在线匹配补全的场景),退回看歌名是否包含中文字符
  /// 兜底——总比没有任何依据、固定选一个顺序更准确。两者都为空/都
  /// 不含中文字符时,判定为外文歌曲。
  static bool isChineseSong({String? artist, String? name}) {
    if (isChineseArtist(artist)) return true;
    if (artist != null && artist.trim().isNotEmpty) {
      // 歌手名非空但不含中文字符,说明这是一个明确的外文歌手署名,
      // 不再退回看歌名——歌名混用中英文很常见,不应该反过来推翻
      // 歌手名给出的更可靠的判断。
      return false;
    }
    if (name == null || name.trim().isEmpty) return false;
    return _cjkPattern.hasMatch(name);
  }
}

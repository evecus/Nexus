/// 网易云音乐 —— 歌曲搜索数据源。
///
/// 使用网易云音乐网页版的公开搜索接口(非官方 API,接口地址/字段结构
/// 可能随时变化)。任何网络异常、返回格式变化都在内部吞掉并返回空
/// 列表,不向上抛异常,方便调用方(多数据源依次尝试的调度逻辑)直接
/// 判断"这个数据源没有结果"。
library online_match_netease_music_source;

import 'package:dio/dio.dart';

import 'online_song_info.dart';

class NeteaseMusicSource {
  NeteaseMusicSource._();

  static final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 8),
    receiveTimeout: const Duration(seconds: 8),
    headers: {
      'Referer': 'https://music.163.com/',
      'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      // 实际生效的 Content-Type 由每次请求的 Options(contentType: ...)
      // 指定(见 search 方法内),这里不重复设置，避免两处不一致造成误导。
    },
  ));

  /// 网页版搜索接口:POST 表单参数 s=关键词&type=1(单曲)&limit=...。
  /// 走 /api/search/get 而非需要加密参数的 /weapi 接口,减少额外的
  /// 加密实现成本,该接口长期以来一直可以被公开访问。
  static const String _searchUrl = 'https://music.163.com/api/search/get';

  static Future<List<OnlineSongInfo>> search({
    required String keyword,
    int limit = 20,
  }) async {
    final kw = keyword.trim();
    if (kw.isEmpty) return const [];

    try {
      // 注意：dio 对 Map 类型的 data 默认按 JSON 编码，不会因为请求头里
      // 写了 x-www-form-urlencoded 就自动转换成表单格式，必须显式指定
      // Options(contentType: ...) 才能让 dio 的内置 Transformer 把这个
      // Map 编码成 "s=xxx&type=1&..." 的表单请求体。
      final resp = await _dio.post(
        _searchUrl,
        data: {
          's': kw,
          'type': 1, // 1 = 单曲
          'limit': limit,
          'offset': 0,
        },
        options: Options(contentType: Headers.formUrlEncodedContentType),
      );

      final data = resp.data;
      final Map<String, dynamic>? json =
          data is Map<String, dynamic> ? data : null;
      if (json == null) return const [];

      final result = json['result'] as Map<String, dynamic>?;
      final songs = result?['songs'] as List?;
      if (songs == null || songs.isEmpty) return const [];

      final out = <OnlineSongInfo>[];
      for (final item in songs) {
        if (item is! Map) continue;
        final song = item;
        final name = (song['name'] as String?)?.trim() ?? '';
        if (name.isEmpty) continue;

        final artistsRaw = song['artists'] as List?;
        final artist = artistsRaw == null
            ? ''
            : artistsRaw
                .whereType<Map>()
                .map((a) => (a['name'] as String?)?.trim() ?? '')
                .where((a) => a.isNotEmpty)
                .join('、');

        final albumMap = song['album'] as Map<String, dynamic>?;
        final album = (albumMap?['name'] as String?)?.trim() ?? '';

        // duration 字段单位是毫秒。
        final durationMs = (song['duration'] as num?)?.toInt() ?? 0;
        final durationSec = durationMs > 0 ? durationMs ~/ 1000 : 0;

        out.add(OnlineSongInfo(
          source: 'netease',
          name: name,
          artist: artist,
          album: album,
          durationSec: durationSec,
        ));
      }
      return out;
    } catch (_) {
      return const [];
    }
  }
}

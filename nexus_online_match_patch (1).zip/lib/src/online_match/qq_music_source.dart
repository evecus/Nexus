/// QQ 音乐 —— 歌曲搜索数据源。
///
/// 使用 QQ 音乐网页版的公开搜索接口(非官方 API,接口地址/字段结构可能
/// 随时变化)。任何网络异常、返回格式变化都在内部吞掉并返回空列表,
/// 不向上抛异常,方便调用方(多数据源依次尝试的调度逻辑)直接判断
/// "这个数据源没有结果",不需要额外套 try/catch。
library online_match_qq_music_source;

import 'dart:convert';

import 'package:dio/dio.dart';

import 'online_song_info.dart';

class QQMusicSource {
  QQMusicSource._();

  static final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 8),
    receiveTimeout: const Duration(seconds: 8),
    headers: {
      // 不带 Referer/UA 部分接口会拒绝请求或返回精简数据。
      'Referer': 'https://y.qq.com/',
      'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    },
    // 该接口偶尔会返回非标准 content-type 的 JSON 文本,交给 dio 按
    // ResponseType.plain 取原始字符串,自己控制解码,避免 dio 内置解析器
    // 因 content-type 不匹配而报错。
    responseType: ResponseType.plain,
  ));

  static const String _searchUrl =
      'https://c.y.qq.com/soso/fcgi-bin/client_search_cp';

  /// 按歌名(可选歌手一并拼进关键词提升命中率)搜索,返回统一格式的候选列表。
  static Future<List<OnlineSongInfo>> search({
    required String keyword,
    int limit = 20,
  }) async {
    final kw = keyword.trim();
    if (kw.isEmpty) return const [];

    try {
      final resp = await _dio.get(
        _searchUrl,
        queryParameters: {
          'w': kw,
          'format': 'json',
          'p': 1,
          'n': limit,
          // platform=yqq.json 返回结果里字段较完整(专辑名/时长都在)。
          'platform': 'yqq.json',
          'needNewCode': 0,
        },
      );

      final raw = resp.data;
      final text = raw is String ? raw : raw.toString();
      final json = _extractJson(text);
      if (json == null) return const [];

      final songData = json['data'] as Map<String, dynamic>?;
      final songList = songData?['song'] as Map<String, dynamic>?;
      final list = songList?['list'] as List?;
      if (list == null || list.isEmpty) return const [];

      final out = <OnlineSongInfo>[];
      for (final item in list) {
        if (item is! Map) continue;
        final song = item;
        final name = (song['songname'] as String?)?.trim() ?? '';
        if (name.isEmpty) continue;

        final singers = song['singer'] as List?;
        final artist = singers == null
            ? ''
            : singers
                .whereType<Map>()
                .map((s) => (s['name'] as String?)?.trim() ?? '')
                .where((s) => s.isNotEmpty)
                .join('、');

        final album = (song['albumname'] as String?)?.trim() ?? '';
        final durationSec = (song['interval'] as num?)?.toInt() ?? 0;

        out.add(OnlineSongInfo(
          source: 'qq',
          name: name,
          artist: artist,
          album: album,
          durationSec: durationSec,
        ));
      }
      return out;
    } catch (_) {
      // 接口字段变化 / 网络失败 / 反爬限制等任何原因都不向上抛异常。
      return const [];
    }
  }

  /// 从原始响应文本中提取第一个 JSON 对象并解码。
  /// 该接口通常直接返回纯 JSON,这里额外做一层裁剪是为了兼容极少数
  /// 情况下响应外层可能带有的空白/BOM 等噪音。
  static Map<String, dynamic>? _extractJson(String text) {
    final trimmed = text.trim();
    final start = trimmed.indexOf('{');
    final end = trimmed.lastIndexOf('}');
    if (start < 0 || end < start) return null;
    try {
      final decoded = jsonDecode(trimmed.substring(start, end + 1));
      return decoded is Map<String, dynamic> ? decoded : null;
    } catch (_) {
      return null;
    }
  }
}

/// 在线音乐信息匹配 —— 统一的搜索结果模型。
///
/// QQ 音乐、网易云音乐两个数据源返回的原始字段名、结构完全不同,
/// [OnlineSongInfo] 是两者搜索结果解析后的统一形状,后续的匹配打分
/// 算法([SongMatcher])只需要认识这一种结构,不需要关心数据来自哪个源。
class OnlineSongInfo {
  /// 数据来源标识,目前是 'qq' 或 'netease',用于日志/调试,不参与匹配。
  final String source;

  /// 歌曲名。
  final String name;

  /// 歌手名。多个歌手已在数据源解析层拼接为统一的分隔符风格
  /// (与 [ArtistSplitter] 能识别的分隔符保持一致,见各 Source 的实现)。
  final String artist;

  /// 专辑名,没有则为空字符串。
  final String album;

  /// 时长,单位:秒。0 表示数据源未返回时长。
  final int durationSec;

  const OnlineSongInfo({
    required this.source,
    required this.name,
    required this.artist,
    required this.album,
    required this.durationSec,
  });

  @override
  String toString() =>
      'OnlineSongInfo(source: $source, name: $name, artist: $artist, '
      'album: $album, durationSec: $durationSec)';
}

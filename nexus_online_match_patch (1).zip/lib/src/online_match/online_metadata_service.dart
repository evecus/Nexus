/// 在线元数据补全服务 —— 对外的统一入口。
///
/// 串联三件事：
/// 1. 用 [SongMatcher] 按歌手语言动态选择数据源查询顺序(中文歌优先
///    QQ 音乐/网易云音乐,外文歌优先 iTunes,详见 SongMatcher 的说明)
///    查询，找出最匹配的在线结果；
/// 2. 只把 [SongEntry] 中**本来是空的**字段（title 为文件名兜底值不算
///    "有效标题"，同样视为空）用在线结果补上——已有值的字段不覆盖，
///    这是本次接入明确要求的策略；
/// 3. 把新补上的字段写回音频文件的 ID3 标签（目前仅支持 MP3；FLAC/OGG
///    文件会跳过写回文件这一步，但仍然会更新 [SongEntry] 内存态字段）。
///
/// 本文件只放在 `lib/src` 共用层，不含任何 UI 代码——具体在哪个页面用
/// 按钮触发、扫描后是否自动触发，留给各平台的 Controller 按需接入。
library online_metadata_service;

import 'dart:io';

import '../music/id3_writer.dart';
import '../music/song_entry.dart';
import 'online_song_info.dart';
import 'song_matcher.dart';

/// 一次在线匹配补全操作的结果，用于 UI 层给用户反馈。
class OnlineMatchResult {
  /// 是否找到了匹配的在线结果(找到但没有任何空字段可补时也算成功)。
  final bool matched;

  /// 匹配到的在线信息，[matched] 为 false 时为 null。
  final OnlineSongInfo? songInfo;

  /// 本次实际补全(原本为空、现在被填上)的字段名集合，
  /// 可能的取值：'title' / 'artist' / 'album'。为空集合表示匹配到了
  /// 结果，但 [SongEntry] 本来就已经没有空字段可补。
  final Set<String> filledFields;

  /// 是否成功写回了音频文件的 ID3 标签。没有字段需要写回、或文件格式
  /// 不支持写入(非 MP3)时为 false，不代表出错。
  final bool wroteToFile;

  const OnlineMatchResult({
    required this.matched,
    required this.songInfo,
    required this.filledFields,
    required this.wroteToFile,
  });

  static const OnlineMatchResult notFound = OnlineMatchResult(
    matched: false,
    songInfo: null,
    filledFields: <String>{},
    wroteToFile: false,
  );
}

class OnlineMetadataService {
  OnlineMetadataService._();

  /// 对单个 [SongEntry] 执行"在线匹配 + 补全空字段 + 写回文件标签"。
  ///
  /// 匹配用的关键词优先使用已有的 title/artist(哪怕已经有值也一样
  /// 用于搜索——搜索关键词跟"要不要覆盖字段"是两回事)；title 为空时
  /// 退回用文件名(去扩展名)当关键词，尽量覆盖"完全没有任何标签"的
  /// 文件。
  ///
  /// [writeToFile] 默认 true：补全了任意字段时尝试写回原始文件的 ID3
  /// 标签(仅 MP3 生效)。传 false 时只更新内存态的 [SongEntry]，不接触
  /// 磁盘上的音频文件，用于用户想"先看看匹配结果对不对，再决定要不要
  /// 写文件"的场景。
  static Future<OnlineMatchResult> matchAndFill(
    SongEntry entry, {
    bool writeToFile = true,
  }) async {
    final searchName = entry.title.trim().isNotEmpty
        ? entry.title.trim()
        : _fileNameWithoutExt(entry.name);
    if (searchName.isEmpty) return OnlineMatchResult.notFound;

    final searchArtist = entry.artist.trim().isNotEmpty ? entry.artist.trim() : null;

    final online = await SongMatcher.matchWithFallback(
      name: searchName,
      artist: searchArtist,
      // SongEntry 目前不持有时长字段，暂不参与时长粗筛；后续如果
      // SongEntry 补充了时长字段，这里直接传入即可，匹配算法已支持。
    );
    if (online == null) {
      return OnlineMatchResult.notFound;
    }

    // 只补"本来是空的"字段。title 的特殊之处：SongEntry.fromScan 会把
    // title 初始化成文件名(去扩展名)兜底，这不算"有效标题"，所以这里
    // 用 metadataLoaded 且 title 非空来判断"是否已经有(哪怕是从文件名
    // 来的)展示用标题"——保守起见，只要 title 是空字符串才补，不去
    // 猜测当前 title 是不是文件名兜底值，避免误覆盖用户手动改过的标题。
    final filled = <String>{};
    String? newTitle;
    String? newArtist;
    String? newAlbum;

    if (entry.title.trim().isEmpty && online.name.trim().isNotEmpty) {
      newTitle = online.name.trim();
      entry.title = newTitle;
      filled.add('title');
    }
    if (entry.artist.trim().isEmpty && online.artist.trim().isNotEmpty) {
      newArtist = online.artist.trim();
      entry.artist = newArtist;
      filled.add('artist');
    }
    if (entry.album.trim().isEmpty && online.album.trim().isNotEmpty) {
      newAlbum = online.album.trim();
      entry.album = newAlbum;
      filled.add('album');
    }

    var wrote = false;
    if (writeToFile && filled.isNotEmpty && await _isMp3(entry.path)) {
      wrote = await Id3Writer.writeTags(
        entry.path,
        title: newTitle,
        artist: newArtist,
        album: newAlbum,
      );
    }

    return OnlineMatchResult(
      matched: true,
      songInfo: online,
      filledFields: filled,
      wroteToFile: wrote,
    );
  }

  /// 批量匹配，[onProgress] 在每首歌处理完成后回调一次(不管成功与否),
  /// 便于 UI 展示进度。内部按顺序逐首处理(不做并发请求)，避免短时间内
  /// 对同一数据源发起大量并发请求触发风控/限流。
  ///
  /// 只会处理"至少有一个字段为空"的歌曲，已经标题/歌手/专辑都齐全的
  /// 条目会被跳过，不计入网络请求次数。
  static Future<List<OnlineMatchResult>> matchAndFillBatch(
    List<SongEntry> entries, {
    bool writeToFile = true,
    void Function(int done, int total, SongEntry current)? onProgress,
  }) async {
    final targets = entries
        .where((e) =>
            e.title.trim().isEmpty ||
            e.artist.trim().isEmpty ||
            e.album.trim().isEmpty)
        .toList();

    final results = <OnlineMatchResult>[];
    for (var i = 0; i < targets.length; i++) {
      final entry = targets[i];
      final result = await matchAndFill(entry, writeToFile: writeToFile);
      results.add(result);
      onProgress?.call(i + 1, targets.length, entry);
    }
    return results;
  }

  static String _fileNameWithoutExt(String fileName) {
    final dot = fileName.lastIndexOf('.');
    return dot > 0 ? fileName.substring(0, dot) : fileName;
  }

  /// 通过文件头魔数判断是否为 MP3(ID3v2)，与 [AudioMetadataReader] 的
  /// 判断方式保持一致；只读取前 3 字节，开销可以忽略。
  static Future<bool> _isMp3(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return false;
      final raf = await file.open();
      try {
        final head = await raf.read(3);
        return head.length == 3 &&
            head[0] == 0x49 &&
            head[1] == 0x44 &&
            head[2] == 0x33; // "ID3"
      } finally {
        await raf.close();
      }
    } catch (_) {
      return false;
    }
  }
}

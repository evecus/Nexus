/// iTunes Search API —— 歌曲搜索数据源。
///
/// 苹果官方提供的公开搜索接口(https://performance-partners.apple.com/search-api),
/// 免费、无需鉴权、条款明确允许这样调用,是三个数据源里唯一"官方且
/// 稳定"的一个——相应地,它的曲库以欧美/日韩等海外音乐为主,中文/
/// 华语歌曲的覆盖率明显弱于 QQ 音乐、网易云音乐,因此只作为外文歌曲
/// 的优先数据源,或者中文歌曲在 QQ/网易云都查不到时的最后兜底。
///
/// 与另外两个数据源一样:任何网络异常、返回格式变化都在内部吞掉并
/// 返回空列表,不向上抛异常。
library online_match_itunes_music_source;

import 'package:dio/dio.dart';

import 'online_song_info.dart';

class ItunesMusicSource {
  ItunesMusicSource._();

  static final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 8),
    receiveTimeout: const Duration(seconds: 8),
  ));

  static const String _searchUrl = 'https://itunes.apple.com/search';

  /// 按歌名(可选歌手一并拼进关键词提升命中率)搜索,返回统一格式的候选列表。
  ///
  /// 不传 country 时用全球默认站点;iTunes 的曲库按国家/地区分开,同一
  /// 首歌在不同 country 下的可搜索性可能不同,但对英文/日文/韩文歌曲
  /// 而言默认站点(相当于美区)通常已经足够覆盖,这里不做多国轮询,
  /// 保持实现简单。
  static Future<List<OnlineSongInfo>> search({
    required String keyword,
    int limit = 20,
  }) async {
    final kw = keyword.trim();
    if (kw.isEmpty) return const [];

    try {
      final resp = await _dio.get(
        _searchUrl,
        queryParameters: {
          'term': kw,
          'media': 'music',
          'entity': 'song',
          'limit': limit,
        },
      );

      final data = resp.data;
      final Map<String, dynamic>? json =
          data is Map<String, dynamic> ? data : null;
      if (json == null) return const [];

      final results = json['results'] as List?;
      if (results == null || results.isEmpty) return const [];

      final out = <OnlineSongInfo>[];
      for (final item in results) {
        if (item is! Map) continue;
        final song = item;
        final name = (song['trackName'] as String?)?.trim() ?? '';
        if (name.isEmpty) continue;

        final artist = (song['artistName'] as String?)?.trim() ?? '';
        final album = (song['collectionName'] as String?)?.trim() ?? '';

        // trackTimeMillis 字段单位是毫秒,部分结果(如未发行/无版权信息)
        // 可能缺失该字段。
        final durationMs = (song['trackTimeMillis'] as num?)?.toInt() ?? 0;
        final durationSec = durationMs > 0 ? durationMs ~/ 1000 : 0;

        out.add(OnlineSongInfo(
          source: 'itunes',
          name: name,
          artist: artist,
          album: album,
          durationSec: durationSec,
        ));
      }
      return out;
    } catch (_) {
      return const [];
    }
  }
}

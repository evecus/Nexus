/// 在线歌曲信息匹配 —— 打分算法与多数据源调度。
///
/// 设计思路参考自 AnyListen 项目的 `findMusic` 算法(见其
/// packages/shared/app/modules/resources/search/music.ts):
/// - 先对候选与目标的歌名/歌手做标准化(去空格、去标点、转小写),
///   避免"周杰伦 (Jay Chou)"和"周杰伦"这类格式差异导致匹配失败。
/// - 有时长信息时,先按时长差是否在容差范围内做一轮粗筛,时长差太大
///   基本可以确定不是同一版本的录音(现场版/纯音乐版时长往往明显不同)。
/// - 依次尝试"歌名+歌手都对上" → "歌名对上,歌手包含" → "歌名包含,
///   歌手对上"等由严到松的条件,取第一个满足条件的候选作为最终结果。
///
/// 数据源调度:按 [ArtistLanguageDetector] 判断出的"这是中文歌还是
/// 外文歌"结果,动态决定三个数据源(QQ 音乐 / 网易云音乐 / iTunes)的
/// 查询顺序——
/// - 中文歌:QQ 音乐 → 网易云音乐 → iTunes(iTunes 华语曲库覆盖弱,
///   放在最后兜底)。
/// - 外文歌:iTunes → QQ 音乐 → 网易云音乐(iTunes 是官方接口、欧美/
///   日韩曲库更全,优先查;查不到再退回华语两家平台,它们也收录不少
///   引进的外语歌曲)。
/// 依次查询,前一个数据源有命中结果就直接返回,不再继续查后面的
/// (减少不必要的网络请求)。
///
/// 与调用方的分工:[SongMatcher] 只负责"给一个查询条件,返回最匹配的
/// 一条在线结果",不关心具体数据源怎么调 —— 那部分由
/// [SongMatcher.matchWithFallback] 里的调度逻辑负责。
library online_match_song_matcher;

import 'artist_language_detector.dart';
import 'itunes_music_source.dart';
import 'netease_music_source.dart';
import 'online_song_info.dart';
import 'qq_music_source.dart';

/// 统一的数据源搜索函数签名,三个数据源的 `search` 静态方法都符合这个
/// 签名,用于在调度逻辑里被当作普通参数按顺序调用。
typedef _SourceSearch = Future<List<OnlineSongInfo>> Function({
  required String keyword,
  int limit,
});

class SongMatcher {
  SongMatcher._();

  /// 匹配时长允许的最大误差(秒)。同一首歌在不同平台的编码/母带时长
  /// 通常只会差 1~2 秒,5 秒的容差足够覆盖正常误差,又能过滤掉明显
  /// 不同版本(如现场版、Remix)的错误匹配。
  static const int _durationToleranceSec = 5;

  /// 中文歌曲的数据源查询顺序:QQ 音乐 → 网易云音乐 → iTunes。
  static const List<_SourceSearch> _chineseSourceOrder = [
    QQMusicSource.search,
    NeteaseMusicSource.search,
    ItunesMusicSource.search,
  ];

  /// 外文歌曲的数据源查询顺序:iTunes → QQ 音乐 → 网易云音乐。
  static const List<_SourceSearch> _foreignSourceOrder = [
    ItunesMusicSource.search,
    QQMusicSource.search,
    NeteaseMusicSource.search,
  ];

  /// 按"歌手语言"动态决定数据源查询顺序,依次查询直到命中或全部查完。
  ///
  /// [name] 歌名、[artist] 歌手为必要的搜索关键词依据,同时 [artist]
  /// (为空时退回用 [name])也是判断中文歌/外文歌的依据,详见
  /// [ArtistLanguageDetector.isChineseSong]。[durationSec] 用于时长
  /// 粗筛的参考值,不传时只按名称/歌手做文本匹配。
  static Future<OnlineSongInfo?> matchWithFallback({
    required String name,
    String? artist,
    int? durationSec,
  }) async {
    if (name.trim().isEmpty) return null;

    final isChinese =
        ArtistLanguageDetector.isChineseSong(artist: artist, name: name);
    final order = isChinese ? _chineseSourceOrder : _foreignSourceOrder;

    for (final searcher in order) {
      final result = await _searchAndMatch(
        searcher: searcher,
        name: name,
        artist: artist,
        durationSec: durationSec,
      );
      if (result != null) return result;
    }
    return null;
  }

  static Future<OnlineSongInfo?> _searchAndMatch({
    required _SourceSearch searcher,
    required String name,
    String? artist,
    int? durationSec,
  }) async {
    // 搜索关键词:有歌手信息时"歌名 歌手"一起搜,命中率通常比只搜歌名高;
    // 排序/打分阶段仍然会用歌名、歌手分别比对,这里只是提高召回。
    final keyword = (artist != null && artist.trim().isNotEmpty)
        ? '$name ${artist.trim()}'
        : name;

    final list = await searcher(keyword: keyword, limit: 20);
    if (list.isEmpty) return null;

    return pickBest(
      candidates: list,
      name: name,
      artist: artist,
      durationSec: durationSec,
    );
  }

  /// 从候选列表中挑出与目标最匹配的一条,没有足够可信的候选时返回 null。
  ///
  /// 暴露为公开方法主要是方便单元测试直接验证打分逻辑,不依赖网络请求。
  static OnlineSongInfo? pickBest({
    required List<OnlineSongInfo> candidates,
    required String name,
    String? artist,
    int? durationSec,
  }) {
    final fName = _normalize(name);
    final fArtist = _normalize(artist ?? '');
    final hasDuration = durationSec != null && durationSec > 0;

    // 先按时长粗筛(仅当目标提供了时长、且候选也返回了时长时才比较;
    // 候选没有时长信息时不能因为"对不上"就排除,直接保留进入下一轮)。
    final filtered = hasDuration
        ? candidates.where((c) {
            if (c.durationSec <= 0) return true;
            return (c.durationSec - durationSec).abs() <= _durationToleranceSec;
          }).toList()
        : candidates;
    final pool = filtered.isEmpty ? candidates : filtered;

    // 由严到松依次尝试匹配条件,命中即返回,不再继续找"更好的"——
    // 因为搜索接口本身已经按相关度排序,同一严格程度下越靠前的结果
    // 通常越可信。
    OnlineSongInfo? tryMatch(bool Function(OnlineSongInfo c) predicate) {
      for (final c in pool) {
        if (predicate(c)) return c;
      }
      return null;
    }

    final normalizedPool = <OnlineSongInfo, (String, String)>{
      for (final c in pool) c: (_normalize(c.name), _normalize(c.artist)),
    };

    // 1) 歌名、歌手都完全一致(标准化后)。
    var best = tryMatch((c) {
      final (n, a) = normalizedPool[c]!;
      return n == fName && (fArtist.isEmpty || a == fArtist);
    });
    if (best != null) return best;

    // 2) 歌名完全一致,歌手互相包含(处理"周杰伦"与"周杰伦、Ade"这类
    //    联合署名场景)。
    best = tryMatch((c) {
      final (n, a) = normalizedPool[c]!;
      return n == fName && _includesEither(a, fArtist);
    });
    if (best != null) return best;

    // 3) 歌手完全一致,歌名互相包含(处理"演唱会版""Live"等后缀差异)。
    if (fArtist.isNotEmpty) {
      best = tryMatch((c) {
        final (n, a) = normalizedPool[c]!;
        return a == fArtist && _includesEither(n, fName);
      });
      if (best != null) return best;
    }

    // 4) 歌名、歌手都只需要互相包含 —— 已经是比较宽松的条件,再往下
    //    放宽容易引入错误匹配,所以到这一步为止。
    best = tryMatch((c) {
      final (n, a) = normalizedPool[c]!;
      return _includesEither(n, fName) && (fArtist.isEmpty || _includesEither(a, fArtist));
    });
    return best;
  }

  /// 标准化:去除常见标点/空格分隔符并转小写,消除不同数据源在格式上
  /// (全角/半角标点、多余空格等)的差异对文本比较造成的干扰。
  static String _normalize(String input) {
    return input
        .toLowerCase()
        .replaceAll(
          RegExp(r'''[\s'".,，。、&`~\-<>|/\[\]!！()（）]'''),
          '',
        );
  }

  static bool _includesEither(String a, String b) {
    if (a.isEmpty || b.isEmpty) return a.isEmpty && b.isEmpty;
    return a.contains(b) || b.contains(a);
  }
}
